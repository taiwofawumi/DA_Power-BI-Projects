
# Content Indexer Pipeline

The **Content Indexer Pipeline** is an ETL solution designed to ingest profile data from curated structured sources, enrich it with AI-generated vector embeddings, and load the content into an Azure AI Search index. This pipeline enables efficient semantic and keyword search capabilities for use cases such as identifying similar, duplicate, or potentially fake profiles in judicial systems.

This project is currently used in the **Michigan Supreme Court Case Name Search** application, where it helps streamline legal research and decision-making by surfacing contextually relevant profiles using hybrid search powered by Azure OpenAI and Azure Cognitive Search.

---

## Getting Started

### 1. Installation

Clone the repository and set up your development environment:
```bash
git clone <your-repo-url>
cd content-indexer
```

### 2. Software Dependencies

Ensure the following tools and libraries are available in your Spark cluster environment:

- **Apache Spark (3.3+)**
- **Databricks Runtime ML 11.3+**
- **Python 3.9+**
- **Azure OpenAI** and **Azure AI Search SDKs**
- **Delta Lake**
- **`requests`, `retry`, `numpy`, `pandas`** (for vector and API operations)

### 3. Configuration

All pipeline behavior is controlled via a centralized `pipeline_configs` dictionary. Below is a detailed lookup table of supported parameters.

| Parameter                   | Description                                                                 |
|----------------------------|-----------------------------------------------------------------------------|
| `env`                      | Environment name (e.g., `sbx`, `dev`, `prod`)                               |
| `source_table`             | Source table in Hive/Databricks to ingest records from                      |
| `openai_endpoint`          | Azure OpenAI endpoint used to generate embeddings                           |
| `openai_key`               | Secret key for accessing Azure OpenAI services                              |
| `embedding_model`          | Model name (e.g., `text-embedding-ada-002`)                                 |
| `embedding_model_version`  | Embedding model API version                                                  |
| `embed_batch_size`         | Number of rows sent to OpenAI per batch                                     |
| `create_index`             | Whether to create a new Azure Search index                                  |
| `aisearch_index_name`      | Name of the Azure Cognitive Search index                                    |
| `aisearch_service_name`    | Azure Search service name                                                    |
| `aisearch_api_version`     | Azure Search API version                                                     |
| `aisearch_api_key`         | Secret key to authenticate Azure Search requests                            |
| `aisearch_index_base_url`  | Base URL to connect to Azure Search                                          |
| `load_batch_size`          | Number of documents sent to the index per batch                             |
| `load_mode`                | Index operation mode (e.g., `mergeOrUpload`)                                 |
| `max_retries`              | Maximum number of retry attempts for transient errors                        |
| `backoff_factor`           | Factor for exponential backoff in retries                                   |
| `max_wait`                 | Maximum wait time (in seconds) for retries                                  |
| `summary_col`              | Column used to summarize the full profile                                   |
| `keyvault_scope`           | Databricks Key Vault scope to retrieve secrets                              |
| `container_name`           | Storage container name for archived output                                  |
| `index_table_path`         | Path to table containing embedded and indexed records                       |
| `deletes_table_path`       | Path to table tracking logically deleted records                            |

### 4. API References

- [Azure OpenAI API](https://learn.microsoft.com/en-us/azure/ai-services/openai/)
- [Azure Cognitive Search API](https://learn.microsoft.com/en-us/rest/api/searchservice/)

---

## Build and Test

To build and run the pipeline:

1. Open the Databricks notebook or script file where the pipeline is defined.
2. Ensure that your Spark cluster is configured with necessary access (Key Vault, Storage, Azure Search, OpenAI).
3. Execute the ETL notebook or script. It will:
   - Read from `source_table`
   - Generate embeddings using OpenAI
   - Archive processed results to storage
   - Load enriched profiles into Azure Cognitive Search

Unit tests and integration tests can be added using `pytest`, mocking APIs and using Delta tables for test data.

```bash
pytest tests/
```

---

## Contribute

We welcome contributions that improve the robustness, performance, or usability of this pipeline. To contribute:

1. Fork the repository.
2. Create a new feature branch.
3. Write clean, documented code and update tests as needed.
4. Submit a pull request describing your change and why it matters.

Feel free to open an issue for bug reports or feature ideas.

---

## Additional Resources

- [How to write a great README](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops)
- Great README examples:
  - [ASP.NET Core](https://github.com/aspnet/Home)
  - [Visual Studio Code](https://github.com/Microsoft/vscode)
  - [Chakra Core](https://github.com/Microsoft/ChakraCore)
