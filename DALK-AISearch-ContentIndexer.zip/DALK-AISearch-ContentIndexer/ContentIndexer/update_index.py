# Databricks notebook source
# MAGIC %md
# MAGIC ### Update Index Pipeline
# MAGIC
# MAGIC This pipeline contains series of functions to:
# MAGIC - Get the data to be loaded / deleted from the index
# MAGIC - Prepare the data for load/delete
# MAGIC - Create required resources and other artifacts, if not available
# MAGIC - Load/delete data from index

# COMMAND ----------

# MAGIC %md
# MAGIC #### Libraries

# COMMAND ----------

!pip install -q azure.search.documents==11.5.2 tiktoken

dbutils.library.restartPython()

# COMMAND ----------

import os
import json
from pyspark.sql.functions import pandas_udf
from datetime import datetime
import pandas as pd
import requests
import math
import time
import concurrent.futures
from delta.tables import DeltaTable
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType, FloatType, StructType, StructField, MapType
from pyspark.sql.window import Window
from utils.configs import *
import traceback
import warnings

# initiate log_messages list
log_messages = []

# Suppress all warnings
warnings.filterwarnings("ignore")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Variables and Constants

# COMMAND ----------

# Set service principal credentials
os.environ["SUBSCRIPTION_ID"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["subscription_id_key"])
os.environ["TENANT_ID"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["tenant_id_key"])
os.environ["CLIENT_ID"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["client_id_key"])
os.environ["CLIENT_SECRET"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["client_secret_key"])

# Set Azure AI Search credentials
os.environ["AZURE_AISEARCH_SERVICE_NAME"] = pipeline_configs["aisearch_service_name"]
os.environ["AZURE_AISEARCH_API_VERSION"] = pipeline_configs["aisearch_api_version"]
os.environ["AZURE_AISEARCH_API_KEY"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["aisearch_api_key"])

# COMMAND ----------

# MAGIC %md
# MAGIC #### Settings and Connections

# COMMAND ----------

# Initialize Spark Session
spark = SparkSession.builder.appName("ContentIndexer").getOrCreate()

# broadcast variables to worker nodes
config_bc = spark.sparkContext.broadcast(pipeline_configs)
aisearch_api_key_bc = spark.sparkContext.broadcast(os.getenv("AZURE_AISEARCH_API_KEY"))
aisearch_api_version_bc = spark.sparkContext.broadcast(os.getenv("AZURE_AISEARCH_API_VERSION"))
aisearch_index_base_url_bc = spark.sparkContext.broadcast(pipeline_configs["aisearch_index_base_url"])

# COMMAND ----------

# MAGIC %md
# MAGIC #### Functions

# COMMAND ----------

def logg(msg):
    log_messages.append(msg)
    log.info(msg)

# Function to create AI Search Index
def create_search_index(index_schema, config):
    headers = {
        "api-key": os.getenv('AZURE_AISEARCH_API_KEY'),
        "Content-Type": "application/json"
    }
    url = f"{config['aisearch_index_base_url']}/indexes/{config['aisearch_index_name']}?api-version={os.getenv('AZURE_AISEARCH_API_VERSION')}"
    payload = json.dumps(index_schema)
        
    response = requests.put(url, headers=headers, data=payload)

    try:
        response.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Error occured while creating index: {e} \n Response Content: {response.text}")
    else:
        logg(f"Index {config['aisearch_index_name']} created successfully!")

def update_load_archive(df, index_table_path):
    # Enable schema auto merge
    spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

    # Add any new columns via an empty append
    empty_df = df.limit(0)
    empty_df.write.format("delta").mode("append").option("mergeSchema", "true").save(index_table_path)

    # Read target schema and find common columns for update
    delta_table = DeltaTable.forPath(spark, index_table_path)
    target_df = delta_table.toDF()
    
    # common columns (excluding merge keys)
    merge_keys = ["IndexUID", "CommitVersion"]
    update_cols = [c for c in df.columns if c in target_df.columns and c not in merge_keys]

    # Build dynamic update clause
    update_clause = ", ".join([f"target.{c} = source.{c}" for c in update_cols])

    # Create temp view for source
    df.createOrReplaceTempView("df_load_status")

    # Run merge dynamically
    merge_query = f"""
    MERGE INTO delta.`{index_table_path}` AS target
    USING df_load_status AS source
    ON target.IndexUID = source.IndexUID AND target.CommitVersion = source.CommitVersion
    WHEN MATCHED THEN UPDATE SET {update_clause}
    """
    # logg("Executing MERGE query:\n", merge_query)
    spark.sql(merge_query)

def load_batch(payloads, search_client, batch_size, max_retries=5, backoff_factor=2, max_wait=30, timeout=30):
    """Sends batch data to Azure AI Search."""
    status_list = []

    def process_batch(batch_data):
        batch_status = None
        for attempt in range(max_retries):
            try:
                response = search_client.upload_documents(documents=batch_data)
                batch_status = "Success"
                break
            except Exception as e:
                if hasattr(e, 'status_code') and e.status_code in {429, 500, 502, 503, 504}:
                    wait_time = min(backoff_factor ** attempt, max_wait)
                    logg(f"Retryable error {e.status_code}: Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    logg(f"Non-retryable error: {str(e)}. Skipping batch.")
                    batch_status = f"Failed: {str(e)[:200]}"
                    break  # Exit retry loop on non-retryable error
        return [batch_status] * len(batch_data)
    
    batches = [payloads[i:i + batch_size] for i in range(0, len(payloads), batch_size)]

    # with threadpooling
    # with concurrent.futures.ThreadPoolExecutor() as executor:
    #     futures = [executor.submit(process_batch, batch_data) for batch_data in batches]
    #     results = [future.result() for future in futures]    
    # status_list = [status for batch_result in results for status in batch_result]

    # without threadpooling
    for batch_data in batches:
        status = process_batch(batch_data)
        status_list.extend(status)

    return status_list
    
@pandas_udf(returnType=StringType())
def load_to_index_udf(payload_batch: pd.Series) -> pd.Series:
    config = config_bc.value
    index_base_url = aisearch_index_base_url_bc.value
    api_version = aisearch_api_version_bc.value
    url = f"{index_base_url}/indexes/{config['aisearch_index_name']}/docs/index?api-version={api_version}"
    headers = {
        "Content-Type": "application/json",
        "api-key": aisearch_api_key_bc.value
    }

    # Initialize SearchClient
    search_client = SearchClient(
        endpoint=index_base_url,
        index_name=config['aisearch_index_name'],
        credential=AzureKeyCredential(aisearch_api_key_bc.value)
    )

    # Ensure payload_batch is a series of dicts
    payloads = [json.loads(payload) for payload in payload_batch]
    for row in payloads:
        row["@search.action"] = config["load_mode"]

    status_list = load_batch(payloads, search_client,
                            batch_size=config["load_batch_size"],
                            max_retries=config["max_retries"], 
                            backoff_factor=config["backoff_factor"], 
                            max_wait=config["max_wait"])

    return pd.Series(status_list)

@pandas_udf(returnType=StringType())
def delete_from_index_udf(payload_batch: pd.Series) -> pd.Series:
    config = config_bc.value
    index_base_url = aisearch_index_base_url_bc.value
    api_version = aisearch_api_version_bc.value
    url = f"{index_base_url}/indexes/{config['aisearch_index_name']}/docs/index?api-version={api_version}"
    headers = {
        "Content-Type": "application/json",
        "api-key": aisearch_api_key_bc.value
    }

    # Initialize SearchClient
    search_client = SearchClient(
        endpoint=index_base_url,
        index_name=config['aisearch_index_name'],
        credential=AzureKeyCredential(aisearch_api_key_bc.value)
    )

    # Ensure payload_batch is a series of dicts
    payloads = [json.loads(payload) for payload in payload_batch]
    for row in payloads:
        row["@search.action"] = "delete"

    status_list = load_batch(payloads, search_client,
                            batch_size=config["load_batch_size"],
                            max_retries=config["max_retries"], 
                            backoff_factor=config["backoff_factor"], 
                            max_wait=config["max_wait"])

    return pd.Series(status_list)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Main Pipeline

# COMMAND ----------

def main(config):
  # log start of batch
  config["BatchStartTime"] = dt_to_str(datetime.now())
  update_table_path = f"/mnt/{config['container_name']}/{config['index_update_table_path']}"
  index_table_path = f"/mnt/{config['container_name']}/{config['index_table_path']}"
  deleted_index_table_path = f"/mnt/{config['container_name']}/{config['deletes_table_path']}"

  # initiate upsert and deletes df
  df_upsert = spark.createDataFrame([], casename_schema).drop(*cols_after_transform) 
  df_delete = spark.createDataFrame([], casename_schema).drop(*cols_after_transform)

  if config["update_index"]:
    # Stage 1: Extract Data
    try:
      if config["update_mode"] == "mergeOrUpload":
        logg(f"Getting casename upsert data")
        df_upsert = spark.read.format("delta").load(update_table_path)

        # # limit to n_records for testing
        # df_upsert = df_upsert.withColumn("index", F.row_number().over(Window.orderBy("IndexUID")))
        # df_upsert = df_upsert.filter((df.index >= 0) & (df_upsert.index <= 100000)).drop("index")
        config["CDCRecordsUpdated"] = df_upsert.count()

        # Convert name cols to Uppercase 
        try:
          df = df.withColumn("PartyName",F.upper(F.col("PartyName")))\
            .withColumn("LastName", F.upper(F.col("LastName"))).withColumn("FirstName", F.upper(F.col("FirstName")))\
              .withColumn("MiddleName", F.upper(F.col("MiddleName"))).withColumn("SuffixName", F.upper(F.col("SuffixName")))
        except:
          pass

        logg(f"""Processing {df_upsert.count()} records for index upsert""")

      elif config["update_mode"] == "delete":
        logg(f"Getting casename delete data")
        df_delete = spark.read.format("delta").load(update_table_path)

        # # limit to n_records for testing
        # df_delete = df_delete.withColumn("index", F.row_number().over(Window.orderBy("IndexUID")))
        # df_delete = df_delete.filter((df_delete.index >= 0) & (df_delete.index <= 100000)).drop("index")
        config["CDCRecordsDeleted"] = df_delete.count()

        logg(f"""Processing {config["CDCRecordsDeleted"]} records for index delete""")

    except Exception as e:
      tb = traceback.format_exc() # enable error traceback
      raise Exception(f"Unable to get data from source: {e} \n{tb}")    
    
    # Stage 2: Create Resources  
    # create aisearch index if required
    try:
      # create index if not already existing
      if config["create_index"]:
        logg("Creating search index") 
        index_schema = get_index_schema(config["aisearch_index_name"])
        # print(json.dumps(index_schema, indent=2))
        create_search_index(index_schema, config)
    except Exception as e:
        tb = traceback.format_exc() # enable error traceback
        raise Exception(f"Error occurred while creating index: {e} \n{tb}")

    # Stage 3: Remove Deleted data from Index
    if not df_delete.isEmpty():
      try:
        logg("Removing deleted data from index")
        df_delete = df_delete.select("IndexUID", "CommitVersion")
        df_delete = df_delete.persist()
        df_delete_payload = df_delete.withColumn("payload", F.to_json(F.struct("IndexUID")))
        df_delete_status = df_delete_payload.withColumn("DeleteStatus", delete_from_index_udf(F.col("payload")))
        # display(df_delete_status.filter("DeleteStatus != 'Success'"))
        # logg("Deleted data successfully removed from index")
        
      except Exception as e:
        tb = traceback.format_exc() # enable error traceback
        raise Exception(f"Error occurred while removing deleted data from index: {e} \n{tb}")

      # Stage 4: Add deleted records to archive
      try:
        # update cummulative table - deletes
        logg("Processing and adding deleted records to archive")
        df_delete_status.drop("payload").write.format("delta").mode("append")\
          .partitionBy("CommitVersion").save(deleted_index_table_path)

        df_delete.unpersist()
        
      except Exception as e:
          tb = traceback.format_exc() # enable error traceback
          raise Exception(f"Error occurred while adding deleted records to archive: {e} \n{tb}")
    
    else:
      logg("No deleted records found")   
      config["CDCRecordsDeleted"] = "0" 

  
    # Stage 7: Add new/updated records to archive
    if not df_upsert.isEmpty():
      try:
        # load embeddings and config to vector db
        logg("Upserting index with records")
        df_index = df_upsert.withColumn("payload", F.to_json(F.struct(*df_upsert.columns)))
        df_load_status = df_index.withColumn("LoadStatus", load_to_index_udf(F.col("payload")))
        # display(df_load_status.filter("LoadStatus != 'Success'"))
        # logg("New/updated records successfully loaded to index")
      
      except Exception as e:
        tb = traceback.format_exc() # enable error traceback
        raise Exception(f"Error occurred while loading data: {e} \n{tb}")

      try:
        # update cummulative table - upserts
        logg("Processing and merging new/updated records to archive")
        update_load_archive(df_load_status.drop("payload"), index_table_path)

      except Exception as e:
        tb = traceback.format_exc() # enable error traceback
        raise Exception(f"Error occurred while archiving index data: {e} \n{tb}")
    
    else:
      logg("No new/updated records found")
      config["CDCRecordsUpdated"] = "0"

  else:
    logg("Update index flag is set to False. Skipping update task.")

  # log end of batch
  config["BatchEndTime"] = dt_to_str(datetime.now())    
  config["Logs"] = log_messages
  logg("Run Completed")

  # exit notebook
  dbutils.notebook.exit(json.dumps(config, indent=2))


# COMMAND ----------

# MAGIC %md
# MAGIC #### Entry Point

# COMMAND ----------

if __name__ == "__main__":
  main(pipeline_configs)


# COMMAND ----------

