import os
import time
from pyspark.sql.types import StringType, IntegerType, FloatType, ArrayType, StructType, StructField, DateType, BooleanType
import logging

# configure logging
def get_logger(name="content-indexer"):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s-%(name)s-%(levelname)s-%(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger

log = get_logger()
env = os.getenv("ENV") # current environment e.g., sbx, dev, staging, prod

pipeline_configs = {
  # === Source Configuration ===
  "source_table": "hive_metastore.intf_casename.casename",  # The Hive table containing source case name data

  # === Service Principal Configuration ===
  "subscription_id_key": "dalk-medallion-storage-subscription-id-01", # subscription id key
  "tenant_id_key": "dalk-medallion-storage-tenant-id-01", # tenant id key
  "client_id_key": "dalk-medallion-storage-app-id-01", # client id key
  "client_secret_key": "dalk-medallion-storage-secret-01", # client secret key

  # === Azure OpenAI Configuration ===
  "create_deployments": False,
  "openai_resource_group": f"dalk-aml-{env}-rg-ugv-01", # Azure OpenAI endpoint resource group name
  "openai_endpoint": f"https://dalk-{env}-oai-ugv-02.openai.azure.us/",  # Azure OpenAI endpoint for embedding generation
  "openai_key": "dalk-openai-api-key-02",  # API key for Azure OpenAI access
  "openai_version": "2025-04-01-preview",  # OpenAI API version
  "openai_model_deployments": [{"model_name":"text-embedding-3-small",
                                "deployment_name":"text-embedding-3-small-indexer", 
                                "capacity": 3650,  
                                "version": "1",
                                "resource_name": f"dalk-{env}-oai-ugv-02",
                                "location": "usgovarizona"}, 
                             {"model_name":"text-embedding-3-small",
                              "deployment_name":"text-embedding-3-small-api", 
                              "capacity": 350,
                              "version": "1",
                              "resource_name": f"dalk-{env}-oai-ugv-02",
                              "location": "usgovarizona"},
                             {"model_name":"gpt-4o",
                              "deployment_name":"gpt-4o", 
                              "capacity": 80, 
                              "version": "2024-05-13",
                              "resource_name": f"dalk-{env}-oai-ugv-02",
                              "location": "usgovarizona"}], 
  "embed_batch_size": 100,  # Number of records sent per embedding batch to OpenAI

  # === Azure AI Search Configuration ===
  "create_index": True,  # Flag to indicate whether to create the index from scratch
  "index_dimension": 256, # Size of the vector dimensions used in the Azure AI Search Index
  "aisearch_index_name": f"cns-{env}-3-small-256-index",  # Name of the AI Search index
  "aisearch_service_name": f"dalk-{env}-azs-ugv-01",  # Azure AI Search service name
  "aisearch_api_version": "2024-09-01-preview",  # API version for AI Search
  "aisearch_api_key": "dalk-aisearch-api-key-01",  # API key for AI Search
  "aisearch_index_base_url": f"https://dalk-{env}-azs-ugv-01.search.azure.us",  # Base URL for accessing the AI Search service
  "load_batch_size": 1000,  # Number of records to load into the index per batch
  "load_mode": "mergeOrUpload",  # Specifies how data should be loaded: mergeOrUpload or upload
  "reconcile_archive_with_index": False, # Flag to indicate whether to reconcile archived records with index records
  "reconcile_archive_with_new_load": True, # Flag to indicate whether to remove any record already successfully processed from new incremental records

  # === Retry Logic Configuration ===
  "max_retries": 5,  # Number of retry attempts for operations
  "backoff_factor": 2,  # Backoff multiplier for exponential wait times between retries
  "max_wait": 30,  # Maximum wait time (in seconds) for retry delays

  # === Pipeline Specific Configuration ===
  "summary_col": "FullProfile",  # Column used for semantic and vector search context
  "keyvault_scope": "dalk-akv-scope",  # Azure Key Vault scope to securely access secrets

  # === Archival and Metadata Configuration ===
  "container_name": "interface",  # Azure storage container for storing index metadata
  "index_table_path": "content-indexer/index/data",  # Path to store indexed (processed) data
  "deletes_table_path": "content-indexer/index/deleted-data",  # Path to store soft-deleted records for tracking
  "index_backup_table_path": "content-indexer/index-backup/data", # Path to backup indexed data
  "deletes_backup_table_path": "content-indexer/index-backup/deleted-data",  # Path to backup soft-deleted records for tracking
  "enable_archive_backup": True,
  "backup_day": 6, # weekday number (0 = Monday, 6 = Sunday)
  "enable_archive_optimization": True,
  "optimization_day": 1, # day of the month

  # === Update Index Task Configuration (Do not change unless you want to run manual update to index) ===
  "update_index": False,  # Flag to indicate whether to update index or not
  "update_mode": "mergeOrUpload",  # mergeOrUpload | delete
  "index_update_table_path": "content-indexer/index-update/data",  # Whether data to be loaded to index is stored
}

# Define invalid value for each column
invalid_data = {
    "CriminalTrackingNumber": ["`", ".", "0", "00", "1", "111", "99", "999", "99999999", "100", 
                            "0000000000", "000000000001", "000000000100", "1111111", 
                            "11111111", "11111111111", "111111111111"],
    "DriversLicenseNumber": ["`", "."],
    "DriversLicenseState": ["`", "."],
    "SSN": ["`", ".", "0", "11111111", "111111111"],
    "PhoneNumber": ["0", "000-000-0000"],
    "DateOfBirth": ["-", "0001-01-01"],
    "StateIDNbr": ["'", " ---------", "0", "IN LEIN", "NONE", "N/A"],
    "City": ["0", "@", "UNKNOWN", "DECEASED", "VICTIM#"],
    "Address1": ["0", "@", "UNKNOWN", "DECEASED", "______________________________", 
            "VICTIM#", "VICTIM#______________________", "***BAD", "***BAD ADDRESS/RETURN MAIL***", 
            "** BAD ADDRESS **", "**RETURNED MAIL", "PARENTAL RIGHTS TERMINATED"],
    "Address2": ["0", "@", "UNKNOWN", "DECEASED", "______________________________",
            "VICTIM#", "VICTIM#______________________", "***BAD", "***BAD ADDRESS/RETURN MAIL***", 
            "** BAD ADDRESS **", "**RETURNED MAIL"]
}

embedding_cols = [   
    "PartyName",
    "DateOfBirth",
    "Address1", 
    "Address2", 
    "City", 
    "State",
    "County",
    "CaseGroup",
    "DriversLicenseState"
]

cols_after_transform = [
    "LastNameSoundsLike",
    "FirstNameSoundsLike",
    "MiddleNameSoundsLike",
    "FullProfile",
    "Embeddings",
    "payload",
    "LoadStatus"
]

index_schema_types = {
    "IndexUID": "Edm.String",
    "CaseUID": "Edm.String",
    "CasePartyUID": "Edm.String",   
    "PartyName": "Edm.String",  
    "LastName": "Edm.String",  
    "FirstName": "Edm.String",  
    "MiddleName": "Edm.String",  
    "SuffixName": "Edm.String",  
    "UPI": "Edm.String",
    "DateOfBirth": "Edm.String",  
    "CaseDocketId": "Edm.String",  
    "OriginalCaseNumber": "Edm.String",   
    "CasePetitionNumber": "Edm.String", 
    "CaseStatus": "Edm.String", 
    "CaseType": "Edm.String", 
    "CaseTypeID": "Edm.String", 
    "County": "Edm.String",
    "CountyID": "Edm.String", 
    "CourtType": "Edm.String", 
    "CourtTypeID": "Edm.String",
    "CourtID": "Edm.String",
    "CourtName": "Edm.String",
    "CaseGroup": "Edm.String",
    "CaseGroupID": "Edm.String", 
    "FileDate": "Edm.DateTimeOffset",
    "PartyType": "Edm.String",
    "PartyNumber": "Edm.String",
    "CriminalTrackingNumber": "Edm.String",
    "HasConviction": "Edm.Boolean",
    "HasWarrant": "Edm.Boolean",
    "IsPublic": "Edm.Boolean",
    "IsFTA": "Edm.Boolean",
    "IsCNSFilter": "Edm.Boolean",
    "IsNonPublic": "Edm.Boolean",
    "IsSetAside": "Edm.Boolean",
    "IsJuvenileProceeding": "Edm.Boolean",
    "IsDelinquencyDiversion": "Edm.Boolean",
    "IsJuvenileConsentCalendar": "Edm.Boolean",
    "IsExtremeRiskProtection": "Edm.Boolean",
    "IsPersonalProtectionProceeding": "Edm.Boolean",
    "IsHYTA": "Edm.Boolean",
    "IsMentalHealthCourt": "Edm.Boolean",
    "IsLicenseHealthCare": "Edm.Boolean",
    "IsSuppressedAddress": "Edm.Boolean",
    "DriversLicenseNumber": "Edm.String",
    "DriversLicenseState": "Edm.String",
    "StateIDNbr": "Edm.String",
    "PhoneNumber": "Edm.String",  
    "SSN": "Edm.String", 
    "Address1": "Edm.String", 
    "Address2": "Edm.String", 
    "City": "Edm.String", 
    "State": "Edm.String", 
    "Zip": "Edm.String",
    "LastNameSoundsLike": "Edm.String",
    "FirstNameSoundsLike": "Edm.String",
    "MiddleNameSoundsLike": "Edm.String",
    "FullProfile": "Edm.String",
    "ChangeType": "Edm.String",
    "CommitVersion": "Edm.String",
    "CommitTimestamp":"Edm.String",
    "Embeddings": "Collection(Edm.Single)",
}

casename_schema = StructType([
    StructField("IndexUID", StringType(), True),
    StructField("ChangeType", StringType(), True),
    StructField("CommitVersion", StringType(), True),
    StructField("CommitTimestamp", StringType(), True),
    StructField("CaseUID", StringType(), True),
    StructField("CasePartyUID", StringType(), True),
    StructField("PartyName", StringType(), True),
    StructField("LastName", StringType(), True),
    StructField("FirstName", StringType(), True),
    StructField("MiddleName", StringType(), True),
    StructField("SuffixName", StringType(), True),
    StructField("UPI", StringType(), True),
    StructField("DateOfBirth", StringType(), True),
    StructField("CaseDocketId", StringType(), True),
    StructField("OriginalCaseNumber", StringType(), True),
    StructField("CasePetitionNumber", StringType(), True),
    StructField("CaseStatus", StringType(), True),
    StructField("CaseType", StringType(), True),
    StructField("CaseTypeID", StringType(), True),
    StructField("County", StringType(), True),
    StructField("CountyID", StringType(), True),
    StructField("CourtType", StringType(), True),
    StructField("CourtTypeID", StringType(), True),
    StructField("CourtID", StringType(), True),
    StructField("CourtName", StringType(), True),
    StructField("CaseGroup", StringType(), True),
    StructField("CaseGroupID", StringType(), True),
    StructField("FileDate", DateType(), True),
    StructField("PartyType", StringType(), True),
    StructField("PartyNumber", StringType(), True),
    StructField("CriminalTrackingNumber", StringType(), True),
    StructField("HasConviction", BooleanType(), True),
    StructField("HasWarrant", BooleanType(), True),
    StructField("IsPublic", BooleanType(), True),
    StructField("IsFTA", BooleanType(), True),
    StructField("IsCNSFilter", BooleanType(), True),
    StructField("IsNonPublic", BooleanType(), True),
    StructField("IsSetAside", BooleanType(), True),
    StructField("IsJuvenileProceeding", BooleanType(), True),
    StructField("IsDelinquencyDiversion", BooleanType(), True),
    StructField("IsJuvenileConsentCalendar", BooleanType(), True),
    StructField("IsExtremeRiskProtection", BooleanType(), True),
    StructField("IsPersonalProtectionProceeding", BooleanType(), True),
    StructField("IsHYTA", BooleanType(), True),
    StructField("IsMentalHealthCourt", BooleanType(), True),
    StructField("IsLicenseHealthCare", BooleanType(), True),
    StructField("IsSuppressedAddress", BooleanType(), True),
    StructField("DriversLicenseNumber", StringType(), True),
    StructField("DriversLicenseState", StringType(), True),
    StructField("StateIDNbr", StringType(), True),
    StructField("PhoneNumber", StringType(), True),
    StructField("SSN", StringType(), True),
    StructField("Address1", StringType(), True),
    StructField("Address2", StringType(), True),
    StructField("City", StringType(), True),
    StructField("State", StringType(), True),
    StructField("Zip", StringType(), True),
    StructField("LastNameSoundsLike", StringType(), True),
    StructField("FirstNameSoundsLike", StringType(), True),
    StructField("MiddleNameSoundsLike", StringType(), True),
    StructField("FullProfile", StringType(), True),
    StructField("Embeddings", ArrayType(FloatType()), True),
    StructField("LoadStatus", StringType(), True)
])

def get_index_schema(index_name):
    index_schema = {
        "name": index_name,
        "fields": [
            {
                "name": "Embeddings",
                "type": "Collection(Edm.Single)",
                "searchable": True,
                "retrievable": True,
                "sortable": False,
                "facetable": False,
                "filterable": False,
                "key": False,
                "dimensions": 256,
                "vectorSearchProfile": f"{index_name}-vector-profile"
            }
        ],
        "vectorSearch": {
            "algorithms": [
                {
                    "name": f"{index_name}-vector-config",
                    "kind": "hnsw",
                    "hnswParameters": 
                    {
                        "m": 4,
                        "efConstruction": 400,
                        "efSearch": 500,
                        "metric": "cosine"
                    }
                }
            ],
            "profiles": [      
                {
                    "name": f"{index_name}-vector-profile",
                    "algorithm": f"{index_name}-vector-config"
                }
        ]
        },
        "semantic": {
            "defaultConfiguration": f"{index_name}-semantic-config",
            "configurations": [
                {
                    "name": f"{index_name}-semantic-config",
                    "prioritizedFields": {
                        "titleField": {
                            "fieldName": "PartyName"
                        },
                        "prioritizedContentFields": [
                            { "fieldName": "FullProfile" }
                        ],
                        "prioritizedKeywordsFields": [
                            { "fieldName": "FullProfile" }
                        ]
                    }
                }
            ]
        }
    }

    for col, col_type in index_schema_types.items():
        if col_type == "Edm.String":
            new_field = {
                "name": col,
                "type": "Edm.String",
                "retrievable": True,
                "filterable": True,
                "sortable": True,
                "facetable": True,
            }
        
            if col == "IndexUID":
                new_field["key"] = True
                new_field["searchable"] = True
            else:
                new_field["searchable"] = True
                new_field["analyzer"] = "en.microsoft"            
            index_schema["fields"].append(new_field)

        elif col_type == "Edm.Boolean":
            new_field = {
                "name": col,
                "type": "Edm.Boolean",
                "retrievable": True,
                "filterable": True,
                "sortable": True,
                "facetable": True,
            }
            index_schema["fields"].append(new_field)
        elif col_type == "Edm.DateTimeOffset":
            new_field = {
                "name": col,
                "type": "Edm.DateTimeOffset",
                "retrievable": True,
                "filterable": True,
                "sortable": True,
                "facetable": True,
            }
            index_schema["fields"].append(new_field)
    
    return index_schema

def dt_to_str(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def retry_func(func, *args, max_retries = 3, retry_delay = 15):
    for attempt in range(max_retries):
        try:
            result = func(*args)
            return result
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            else:
                log.error(f"Function {func.__name__} failed after {max_retries} attempt: {e}")

get_data_query = """SELECT * FROM (
                            SELECT
                                SHA(CONCAT_WS("|", CaseUID, CasePartyUID)) as IndexUID,
                                CAST(PartyName AS STRING) AS PartyName,
                                CAST(LastName AS STRING) AS LastName,
                                CAST(FirstName AS STRING) AS FirstName,
                                CAST(MiddleName AS STRING) AS MiddleName,
                                CAST(SuffixName AS STRING) AS SuffixName,
                                CAST(CaseUID AS STRING) AS CaseUID,
                                CAST(CasePartyUID AS STRING) AS CasePartyUID,
                                CAST(UPI AS STRING) AS UPI,
                                CAST(DateOfBirth AS STRING) AS DateOfBirth,
                                CAST(CaseDocketId AS STRING) AS CaseDocketId,
                                CAST(OriginalCaseNumber AS STRING) AS OriginalCaseNumber,
                                CAST(CasePetitionNumber AS STRING) AS CasePetitionNumber,
                                CAST(CaseStatus AS STRING) AS CaseStatus,
                                CAST(CaseType AS STRING) AS CaseType,
                                CAST(CaseTypeID AS STRING) AS CaseTypeID,
                                CAST(County AS STRING) AS County,
                                CAST(CountyID AS STRING) AS CountyID,
                                CAST(CourtType AS STRING) AS CourtType,
                                CAST(CourtTypeID AS STRING) AS CourtTypeID,
                                CAST(CourtID AS STRING) AS CourtID,
                                CAST(CourtName AS STRING) AS CourtName,
                                CAST(CaseGroup AS STRING) AS CaseGroup,
                                CAST(CaseGroupID AS STRING) AS CaseGroupID,
                                FileDate,
                                CAST(PartyType AS STRING) AS PartyType,
                                CAST(PartyNumber AS STRING) AS PartyNumber,
                                CAST(CriminalTrackingNumber AS STRING) AS CriminalTrackingNumber,
                                HasConviction,
                                HasWarrant,
                                IsPublic,
                                IsFTA,
                                IsCNSFilter, 
                                IsNonPublic, 
                                IsSetAside, 
                                IsJuvenileProceeding, 
                                IsDelinquencyDiversion, 
                                IsJuvenileConsentCalendar, 
                                IsExtremeRiskProtection, 
                                IsPersonalProtectionProceeding, 
                                IsHYTA, 
                                IsMentalHealthCourt, 
                                IsLicenseHealthCare,
                                IsSuppressedAddress,
                                CAST(DriversLicenseNumber AS STRING) AS DriversLicenseNumber,
                                CAST(DriversLicenseState AS STRING) AS DriversLicenseState,
                                CAST(StateIDNbr AS STRING) AS StateIDNbr,
                                CAST(PhoneNumber AS STRING) AS PhoneNumber,
                                CAST(SSN AS STRING) AS SSN,
                                CAST(Address1 AS STRING) AS Address1,
                                CAST(Address2 AS STRING) AS Address2,
                                CAST(City AS STRING) AS City,
                                CAST(State AS STRING) AS State,
                                CAST(Zip AS STRING) AS Zip,
                                CAST(_change_type AS STRING) AS ChangeType,
                                CAST(_commit_timestamp AS STRING) AS CommitTimestamp,
                                CAST(_commit_version AS STRING) AS CommitVersion,
                                RANK() OVER(
                                    PARTITION BY SHA(CONCAT_WS("|", CaseUID, CasePartyUID)) 
                                    ORDER BY _commit_version DESC) AS Rank
                            FROM table_changes(?, ?)
                            WHERE _change_type != 'update_preimage'
                ) WHERE Rank = 1"""