# Databricks notebook source
# MAGIC %md
# MAGIC ### Content Indexer Pipeline
# MAGIC
# MAGIC This pipeline contains series of functions to:
# MAGIC - Get the latest casename data
# MAGIC - Prepare the data for loading to a vector index
# MAGIC - Create required resources and other artifacts, if not available
# MAGIC - Load vector embeddings and metadata to vector database
# MAGIC - Archive vector embeddings and metadata in storage account

# COMMAND ----------

# MAGIC %md
# MAGIC #### Libraries

# COMMAND ----------

!pip install -q openai==1.57.2 azure.search.documents==11.5.2 tiktoken

dbutils.library.restartPython()

# COMMAND ----------

import os
import json
from pyspark.sql.functions import pandas_udf
from datetime import datetime
import pandas as pd
import requests
import math
import time
import openai
import tiktoken
from delta.tables import DeltaTable
import concurrent.futures
from openai import AzureOpenAI
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.core.credentials import AzureKeyCredential
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType, FloatType, StructType, StructField, MapType
from pyspark.sql.window import Window
from utils.configs import *
import traceback
import warnings

# initiate log_messages list
log_messages = []

# Suppress all warnings
warnings.filterwarnings("ignore")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Variables and Constants

# COMMAND ----------

# Set service principal credentials
os.environ["SUBSCRIPTION_ID"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["subscription_id_key"])
os.environ["TENANT_ID"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["tenant_id_key"])
os.environ["CLIENT_ID"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["client_id_key"])
os.environ["CLIENT_SECRET"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["client_secret_key"])

# Set Azure OpenAI credentials
os.environ["AZURE_OPENAI_API_KEY"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["openai_key"]) 
os.environ["AZURE_OPENAI_ENDPOINT"] = pipeline_configs["openai_endpoint"]
os.environ["AZURE_OPENAI_EMBEDDING_MODEL"]= pipeline_configs["openai_model_deployments"][0]["deployment_name"]
os.environ["AZURE_OPENAI_VERSION"] = pipeline_configs["openai_version"]

# Set Azure AI Search credentials
os.environ["AZURE_AISEARCH_SERVICE_NAME"] = pipeline_configs["aisearch_service_name"]
os.environ["AZURE_AISEARCH_API_VERSION"] = pipeline_configs["aisearch_api_version"]
os.environ["AZURE_AISEARCH_API_KEY"] = dbutils.secrets.get(scope=pipeline_configs["keyvault_scope"], key=pipeline_configs["aisearch_api_key"])

# COMMAND ----------

# MAGIC %md
# MAGIC #### Settings and Connections

# COMMAND ----------

# Initialize Spark Session
spark = SparkSession.builder.appName("ContentIndexer").getOrCreate()
tokenizer = tiktoken.get_encoding("cl100k_base")

# broadcast variables to worker nodes
config_bc = spark.sparkContext.broadcast(pipeline_configs)
openai_api_key_bc = spark.sparkContext.broadcast(os.getenv("AZURE_OPENAI_API_KEY"))
openai_endpoint_bc = spark.sparkContext.broadcast(os.getenv("AZURE_OPENAI_ENDPOINT"))
openai_api_embedding_model_bc = spark.sparkContext.broadcast(os.getenv("AZURE_OPENAI_EMBEDDING_MODEL"))
openai_api_version_bc = spark.sparkContext.broadcast(os.getenv("AZURE_OPENAI_VERSION"))
aisearch_api_key_bc = spark.sparkContext.broadcast(os.getenv("AZURE_AISEARCH_API_KEY"))
aisearch_api_version_bc = spark.sparkContext.broadcast(os.getenv("AZURE_AISEARCH_API_VERSION"))
aisearch_index_base_url_bc = spark.sparkContext.broadcast(pipeline_configs["aisearch_index_base_url"])

# COMMAND ----------

# MAGIC %md
# MAGIC #### Functions

# COMMAND ----------

def logg(msg):
    log_messages.append(msg)
    log.info(msg)

# Function to preprocess df
def get_casename_data(config):
    # query source table to get updates since last run
    source_table = config['source_table'] # table name
    last_run_time = config["LastRunTimeStamp"] # starting point for capturing changes
    df = spark.sql(get_data_query, (source_table, last_run_time))
    # display(df.limit(10))      
    return df

# Function to retrieve timestamp when CDC is enabled
def get_cdc_ts(table_path):

    if not spark.catalog.tableExists(table_path):
        return None
    
    df_history = spark.sql(f"DESCRIBE HISTORY {table_path}")
    enabled_df = df_history.filter(
        F.col("operationParameters")["properties"].contains("delta.enableChangeDataFeed"))

    # Get the lastest delta.enableChangeDataFeed timestamp
    rows = enabled_df.select("timestamp").orderBy("timestamp", ascending=False).collect()
    
    if rows and rows[0][0] is not None:
        return dt_to_str(rows[0][0])
    else:
        return None

# Function to retrieve LastRunTimeStamp
def get_parameter(param):

    # set default value
    if param == "LastRunTimeStamp":
        default_value = retry_func(get_cdc_ts, pipeline_configs["source_table"])
    elif param == "is_initial_load":
        default_value = "false"
    else:
        default_value = ""

    # get parameter value
    dbutils.widgets.text(param, default_value, param)
    var = dbutils.widgets.get(param)
    if var:
        return var
    else:
        logg(f"No valid input found for {param}. Using default value: {default_value}")
        return default_value

# Function to check if a path exists
def path_exists(path):
    try:
        dbutils.fs.ls(path)  # List contents to check if path exists
        return True
    except Exception as e:
        return False

@udf(returnType=StringType())
def modifiedNysiis(name_column):
    if name_column is None or name_column.strip() == "":
        return ""

    # Convert to uppercase and remove non-alphabetic characters
    name = ""
    for ch in name_column:
        if 'a' <= ch <= 'z':
            name += chr(ord(ch) - 32)
        elif 'A' <= ch <= 'Z':
            name += ch
    if not name:
        return ""

    first_char = name[0]

    '''
    # Remove trailing JR or SR --> commented out to match C code
    while name.endswith("JR") or name.endswith("SR"):
        name = name[:-2]
        if not name:
            return ""
    '''

    # Remove trailing S or Z
    while name.endswith("S") or name.endswith("Z"):
        name = name[:-1]
        if not name:
            return ""

    # Initial substitutions
      # FROM 'MAC' TO 'MCC'
      # FROM 'PF' TO 'FF'
    if name.startswith("MAC"):
        name = "MCC" + name[3:]
    if name.startswith("PF"):
        name = "FF" + name[2:]

    # Ending substitutions
      # FROM 'NDT' 'NRT' 'NRD' TO N
      # FROM 'IX' TO 'IC'
      # FROM 'EX' TO 'EC'
      # FROM 'YE' 'EE' 'IE' TO 'Y'
      # FROM 'DT' 'RT' 'RD' TO 'D'
      # FROM 'NT' 'ND' TO 'N'
    if name.endswith("NDT") or name.endswith("NRT") or name.endswith("NRD"):
        name = name[:-3] + "N"
    if name.endswith("IX"):
        name = name[:-2] + "IC"
    if name.endswith("EX"):
        name = name[:-2] + "EC"
    if name.endswith("YE") or name.endswith("EE") or name.endswith("IE"):
        name = name[:-2] + "Y"
    if name.endswith("DT") or name.endswith("RT") or name.endswith("RD"):
        name = name[:-2] + "D"
    if name.endswith("NT") or name.endswith("ND"):
        name = name[:-2] + "N"

    # Begin main transformation
    name_chars = list(name)
    i = 0
    while i < len(name_chars):
        # transcode 'EV' to 'EF' if not at start of name
        if i > 0 and i < len(name_chars) - 1:
            if name_chars[i] == 'E' and name_chars[i+1] == 'V':
                name_chars[i+1] = 'F'

        # Replace all vowels with A
        if name_chars[i] in ['E', 'I', 'O', 'U']:
            name_chars[i] = 'A'
            # replace any HA with AA that are not the first two characters
            if i > 1 and name_chars[i-1] == 'H':
                name_chars[i-1] = 'A'

        # Remove W after vowel
        if i < len(name_chars) - 1:
            if name_chars[i] == 'A' and name_chars[i+1] == 'W':
                name_chars[i+1] = 'A'

        # GHT → GT
        if i < len(name_chars) - 2:
            if name_chars[i] == 'G' and name_chars[i+1] == 'H' and name_chars[i+2] == 'T':
                name_chars[i+1] = 'G'

        # DG → G
        if i < len(name_chars) - 1:
            if name_chars[i] == 'D' and name_chars[i+1] == 'G':
                name_chars[i] = 'G'

        # PH → FF
        if i < len(name_chars) - 1:
            if name_chars[i] == 'P' and name_chars[i+1] == 'H':
                name_chars[i] = 'F'
                name_chars[i+1] = 'F'

        # Remove H between or next to vowels
        if i < len(name_chars) - 1:
            if name_chars[i] == 'A' and name_chars[i+1] == 'H':
                name_chars[i+1] = 'A'
        if i > 0 and i < len(name_chars) - 1:
            if name_chars[i] == 'H' and name_chars[i+1] == 'A':
                name_chars[i] = 'A'

        # KN → N, else K → C
        if name_chars[i] == 'K':
            if i < len(name_chars) - 1 and name_chars[i+1] == 'N':
                name_chars[i] = 'N'
            else:
                name_chars[i] = 'C'

        # M → N (if not first character)
        if i > 0 and name_chars[i] == 'M':
            name_chars[i] = 'N'

        # Q → G (if not first character)
        if i > 0 and name_chars[i] == 'Q':
            name_chars[i] = 'G'

        # SCH → S
        if i < len(name_chars) - 2:
            if name_chars[i] == 'S' and name_chars[i+1] == 'C' and name_chars[i+2] == 'H':
                name_chars[i+1] = 'S'
                name_chars[i+2] = 'S'

        # SH → S
        if i < len(name_chars) - 1:
            if name_chars[i] == 'S' and name_chars[i+1] == 'H':
                name_chars[i+1] = 'S'

        # YW → Y
        if i < len(name_chars) - 1:
            if name_chars[i] == 'Y' and name_chars[i+1] == 'W':
                name_chars[i+1] = 'Y'

        # Y → A (if not first or last char)
        if i > 0 and i < len(name_chars) - 1:
            if name_chars[i] == 'Y':
                name_chars[i] = 'A'

        # WR → R
        if i < len(name_chars) - 1:
            if name_chars[i] == 'W' and name_chars[i+1] == 'R':
                name_chars[i] = 'R'

        # Z → S (if not first character)
        if i > 0 and name_chars[i] == 'Z':
            name_chars[i] = 'S'

        i += 1

    # Remove trailing vowels (A)
    while name_chars and name_chars[-1] == 'A':
        name_chars.pop()

    # Collapse repeated characters
    result = []
    for ch in name_chars:
        if not result or result[-1] != ch:
            result.append(ch)

    # Transcode AY → Y
    if len(result) >= 2 and result[-2] == 'A' and result[-1] == 'Y':
        result = result[:-2] + ['Y']

    # Collapse again
    final = []
    for ch in result:
        if not final or final[-1] != ch:
            final.append(ch)

    # Restore first char if it was a vowel and first result char is 'A'
    if final and final[0] == 'A':
        final[0] = first_char.upper()

    return ''.join(final)
    
@udf(returnType=IntegerType())
def count_tokens_udf(text):
    if text is None:
        return 0
    return len(tokenizer.encode(text))

def is_valid_value(col_name):
    """
    Generate a condition to check if the column value is NOT in the list of patterns to be cleaned.
    """
    base_condition = (F.col(col_name).isNotNull()) & (F.trim(F.col(col_name)) != "")

    # Get invalid patterns for this column, if any
    invalid_patterns = invalid_data.get(col_name, [])
    for pattern in invalid_patterns:
        base_condition = base_condition & (F.col(col_name) != F.lit(pattern))
    return base_condition

# Function to get azure AD token
def get_azure_ad_token():
    url = f"https://login.microsoftonline.us/{os.getenv('TENANT_ID')}/oauth2/v2.0/token"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "grant_type": "client_credentials",
        "client_id": os.getenv('CLIENT_ID'),
        "client_secret": os.getenv('CLIENT_SECRET'),
        "scope": "https://management.usgovcloudapi.net/.default"
    }
    response = requests.post(url, headers=headers, data=data)

    if response.status_code != 200:
        logg("ERROR:", response.status_code, response.text)
        response.raise_for_status()

    return response.json()["access_token"]

# Function to create OpenAI deployment model
def create_openai_deployment(
    subscription_id: str,
    resource_group: str,
    resource_name: str,
    deployment_name: str,
    model_name: str,
    model_version: str,
    model_capacity: str,
    location: str,
    api_version: str,
    azure_token: str
):
    """
    Creates a deployment for a given Azure OpenAI model.
    """
    # Deployment endpoint
    url = (
        f"https://management.usgovcloudapi.net/subscriptions/{subscription_id}/"
        f"resourceGroups/{resource_group}/providers/Microsoft.CognitiveServices/"
        f"accounts/{resource_name}/deployments/{deployment_name}?api-version={api_version}"
    )

    # Deployment configuration
    payload = {
        "properties": {
            "model": {
                "format": "OpenAI",
                "name": model_name,
                "version": model_version
                }
        },
        "sku": {
            "name": "Standard",
            "capacity": model_capacity
        },
        "location": location
    }

    headers = {
        "Authorization": f"Bearer {azure_token}",
        "Content-Type": "application/json"
    }

    response = requests.put(url, headers=headers, data=json.dumps(payload))

    if response.status_code in (200, 201):
        logg(f"Deployment '{deployment_name}' created successfully.")
    else:
        logg(f"Failed to create deployment: {response.status_code}")
        logg(response.text)

# Function to create AI Search Index
def create_search_index(index_schema, config):
    headers = {
        "api-key": os.getenv('AZURE_AISEARCH_API_KEY'),
        "Content-Type": "application/json"
    }
    url = f"{config['aisearch_index_base_url']}/indexes/{config['aisearch_index_name']}?api-version={os.getenv('AZURE_AISEARCH_API_VERSION')}"
    payload = json.dumps(index_schema)
        
    response = requests.put(url, headers=headers, data=payload)

    try:
        response.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Error occured while creating index: {e} \n Response Content: {response.text}")
    else:
        logg(f"Index {config['aisearch_index_name']} created successfully!")

# Function to delete AI Search Index
def delete_search_index(config):
    try:
        # Initialize SearchIndexClient
        index_client = SearchIndexClient(
            endpoint=config['aisearch_index_base_url'],
            credential=AzureKeyCredential(os.getenv("AZURE_AISEARCH_API_KEY"))
        )

        # delete index
        index_client.delete_index(config['aisearch_index_name'])
        logg(f"Index {config['aisearch_index_name']} deleted!")

    except Exception as e:
        raise RuntimeError(f"Error occured while deleting index: {e} \n Response Content: {response.text}")        

def update_load_archive(df, index_table_path):
      # **MERGE INTO to update LoadStatus in the index table**
      df.createOrReplaceTempView("df_load_status")

      merge_query = f"""
      MERGE INTO delta.`{index_table_path}` target
      USING df_load_status source
      ON target.IndexUID = source.IndexUID AND target.CommitVersion = source.CommitVersion
      WHEN MATCHED AND target.LoadStatus != source.LoadStatus THEN 
          UPDATE SET target.LoadStatus = source.LoadStatus
      WHEN NOT MATCHED THEN 
          INSERT *
      """
      spark.sql(merge_query)

def get_archive_df(index_table_path, deleted_index_table_path):
    if path_exists(index_table_path):
        df_index_table = spark.read.format("delta").load(index_table_path)
        df_success = df_index_table.filter("LoadStatus = 'Success'") # successful records from previous runs
    else:
        df_success = spark.createDataFrame([],schema = casename_schema)

    if path_exists(deleted_index_table_path):
        df_deleted = spark.read.format("delta").load(deleted_index_table_path).filter("DeleteStatus = 'Success'") # deleted records from previous runs
        df_deleted = df_deleted.select("IndexUID", "CommitVersion").distinct()
    else:
        df_deleted = spark.createDataFrame([],schema = casename_schema).select("IndexUID", "CommitVersion")

    # processed index records minus deleted records
    df_index_archive = df_success.join(df_deleted, on=["IndexUID", "CommitVersion"], how="left_anti")
    
    return df_index_archive
    
# Function to generate embeddings for a batch with rate limiting and retries
def generate_embeddings_batch(text_batch, embedding_client, index_dim, batch_size=50, max_retries=5, backoff_factor=2, max_wait=60):
    embeddings = []

    def process_batch(batch):
        retries = 0
        batch_embeddings = [None] * len(batch)
        while retries <= max_retries:
            try:
                logg(f"Generating embeddings for a batch of size {len(batch)}. Attempt {retries + 1}/{max_retries}")
                
                # Make the API call
                response = embedding_client.embeddings.create(
                    input=batch,
                    model=openai_api_embedding_model_bc.value,
                    dimensions=index_dim
                )

                # Validate and extract embeddings
                if hasattr(response, 'data') and response.data:
                    batch_embeddings = [item.embedding for item in response.data]  

                break  # Exit retry loop if successful

            except Exception as e:
                # Check for retryable errors
                if hasattr(e, 'status_code') and e.status_code in {429, 500, 502, 503, 504}:
                    wait_time = min(backoff_factor ** retries, max_wait)
                    logg(f"Retryable error {e.status_code}: Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                    retries += 1
                else:
                    logg(f"Non-retryable error: {str(e)}. Skipping batch.")
                    break  # Exit retry loop on non-retryable error
        
        return batch_embeddings
    
    batches = [text_batch[i:i + batch_size] for i in range(0, len(text_batch), batch_size)]

    # with threadpooling
    # with concurrent.futures.ThreadPoolExecutor() as executor:
    #     futures = [executor.submit(process_batch, batch) for batch in batches]
    #     results = [future.result() for future in futures] 
    # embeddings = [result for batch_result in results for result in batch_result]

    # without threadpooling
    for batch in batches:
        batch_embeddings = process_batch(batch)
        embeddings.extend(batch_embeddings)

    return embeddings

@pandas_udf(returnType=ArrayType(FloatType()))
def generate_embeddings_udf(text_batch: pd.Series) -> pd.Series:
    config = config_bc.value
    embedding_client = AzureOpenAI(
                    api_key=openai_api_key_bc.value,  
                    api_version=openai_api_version_bc.value,
                    azure_endpoint=openai_endpoint_bc.value
                )
    text_list = text_batch.tolist()
    embeddings = generate_embeddings_batch(text_list, embedding_client,
                                           batch_size=config["embed_batch_size"],
                                           index_dim = config["index_dimension"],
                                           max_retries=config["max_retries"], 
                                           backoff_factor=config["backoff_factor"], 
                                           max_wait=config["max_wait"])
    return pd.Series(embeddings)


def load_batch(payloads, search_client, batch_size, max_retries=5, backoff_factor=2, max_wait=30, timeout=30):
    """Sends batch data to Azure AI Search."""
    status_list = []

    def process_batch(batch_data):
        batch_status = None
        for attempt in range(max_retries):
            try:
                response = search_client.upload_documents(documents=batch_data)
                batch_status = "Success"
                break
            except Exception as e:
                if hasattr(e, 'status_code') and e.status_code in {429, 500, 502, 503, 504}:
                    wait_time = min(backoff_factor ** attempt, max_wait)
                    logg(f"Retryable error {e.status_code}: Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    logg(f"Non-retryable error: {str(e)}. Skipping batch.")
                    batch_status = f"Failed: {str(e)[:200]}"
                    break  # Exit retry loop on non-retryable error
        return [batch_status] * len(batch_data)
    
    batches = [payloads[i:i + batch_size] for i in range(0, len(payloads), batch_size)]

    # with threadpooling
    # with concurrent.futures.ThreadPoolExecutor() as executor:
    #     futures = [executor.submit(process_batch, batch_data) for batch_data in batches]
    #     results = [future.result() for future in futures]    
    # status_list = [status for batch_result in results for status in batch_result]

    # without threadpooling
    for batch_data in batches:
        status = process_batch(batch_data)
        status_list.extend(status)

    return status_list

@pandas_udf(returnType=StringType())
def load_to_index_udf(payload_batch: pd.Series) -> pd.Series:
    config = config_bc.value
    index_base_url = aisearch_index_base_url_bc.value
    api_version = aisearch_api_version_bc.value
    url = f"{index_base_url}/indexes/{config['aisearch_index_name']}/docs/index?api-version={api_version}"
    headers = {
        "Content-Type": "application/json",
        "api-key": aisearch_api_key_bc.value
    }

    # Initialize SearchClient
    search_client = SearchClient(
        endpoint=index_base_url,
        index_name=config['aisearch_index_name'],
        credential=AzureKeyCredential(aisearch_api_key_bc.value)
    )

    # Ensure payload_batch is a series of dicts
    payloads = [json.loads(payload) for payload in payload_batch]
    for row in payloads:
        row["@search.action"] = config["load_mode"]

    status_list = load_batch(payloads, search_client,
                            batch_size=config["load_batch_size"],
                            max_retries=config["max_retries"], 
                            backoff_factor=config["backoff_factor"], 
                            max_wait=config["max_wait"])

    return pd.Series(status_list)

@pandas_udf(returnType=StringType())
def delete_from_index_udf(payload_batch: pd.Series) -> pd.Series:
    config = config_bc.value
    index_base_url = aisearch_index_base_url_bc.value
    api_version = aisearch_api_version_bc.value
    url = f"{index_base_url}/indexes/{config['aisearch_index_name']}/docs/index?api-version={api_version}"
    headers = {
        "Content-Type": "application/json",
        "api-key": aisearch_api_key_bc.value
    }

    # Initialize SearchClient
    search_client = SearchClient(
        endpoint=index_base_url,
        index_name=config['aisearch_index_name'],
        credential=AzureKeyCredential(aisearch_api_key_bc.value)
    )

    # Ensure payload_batch is a series of dicts
    payloads = [json.loads(payload) for payload in payload_batch]
    for row in payloads:
        row["@search.action"] = "delete"

    status_list = load_batch(payloads, search_client,
                            batch_size=config["load_batch_size"],
                            max_retries=config["max_retries"], 
                            backoff_factor=config["backoff_factor"], 
                            max_wait=config["max_wait"])

    return pd.Series(status_list)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Main Pipeline

# COMMAND ----------

def main(config):
  config["LastRunTimeStamp"] = get_parameter("LastRunTimeStamp")
  config["is_initial_load"] = get_parameter("is_initial_load")

  # Initiate Variables
  config["BatchStartTime"] = dt_to_str(datetime.now())
  index_table_path = f"/mnt/{config['container_name']}/{config['index_table_path']}"
  deleted_index_table_path = f"/mnt/{config['container_name']}/{config['deletes_table_path']}"
  index_backup_table_path = f"/mnt/{config['container_name']}/{config['index_backup_table_path']}"
  deleted_index_backup_table_path = f"/mnt/{config['container_name']}/{config['deletes_backup_table_path']}"

  df_upsert = spark.createDataFrame([], casename_schema).drop(*cols_after_transform) 
  df_delete = spark.createDataFrame([], casename_schema).drop(*cols_after_transform) 

  # Stage 1: Create Resources
  # set up environment if initial load
  try:
    if config["is_initial_load"].lower() == "true":
      logg("Setting up environment for initial load")

      # reset LastRunTimeStamp
      config["LastRunTimeStamp"] = retry_func(get_cdc_ts, config["source_table"])

      # drop archive tables
      logg("Dropping archive tables")
      dbutils.fs.rm(index_table_path, recurse=True)
      dbutils.fs.rm(deleted_index_table_path, recurse=True)
      
      # delete index
      logg(f"Deleting index {config['aisearch_index_name']}")
      delete_search_index(config)

      # re-create index
      logg(f"Re-creating index {config['aisearch_index_name']}")
      index_schema = get_index_schema(config["aisearch_index_name"])
      # print(json.dumps(index_schema, indent=2))
      create_search_index(index_schema, config)
    
  except Exception as e:
    tb = traceback.format_exc() # enable error traceback
    raise Exception(f"Setting up environment for initial load: {e} \n{tb}")

  # create openai deployments if required
  try:
    if config["create_deployments"]:
      logg("Creating openai deployments")
      token = get_azure_ad_token()
      for model in config["openai_model_deployments"]:
        create_openai_deployment(
                subscription_id = os.getenv('SUBSCRIPTION_ID').strip(),
                resource_group = config['openai_resource_group'],
                resource_name = model['resource_name'],
                deployment_name = model['deployment_name'],
                model_name = model['model_name'],
                model_version = model['version'],
                model_capacity = model['capacity'],
                location = model['location'],
                api_version = config['openai_version'],
                azure_token = token
            )
  except Exception as e:
      tb = traceback.format_exc() # enable error traceback
      raise Exception(f"Error occurred while creating deployments: {e} \n{tb}")

  # create aisearch index if required
  try:
    # create index if not already existing
    if config["create_index"]:
      logg("Creating search index") 
      index_schema = get_index_schema(config["aisearch_index_name"])
      # print(json.dumps(index_schema, indent=2))
      create_search_index(index_schema, config)
  except Exception as e:
      tb = traceback.format_exc() # enable error traceback
      raise Exception(f"Error occurred while creating index: {e} \n{tb}")
  
  # Stage 2: Extract Data
  # Get failed records from previous runs
  logg(f"Getting failed records from previous runs")
  if path_exists(index_table_path):
    df_index_table = spark.read.format("delta").load(index_table_path)
    df_failed = df_index_table.filter("LoadStatus != 'Success'").drop(*cols_after_transform)
  else:
    df_failed = spark.createDataFrame([],schema = casename_schema).drop(*cols_after_transform)

  logg(f"Found {df_failed.count()} failed records from previous runs to be included in this run.")

  # Get latest changes to casename data
  try:
    logg(f"Getting latest changes to casename data since last run time: {config['LastRunTimeStamp']}")
    df = get_casename_data(config)

    # # limit to n_records for testing
    # df = df.filter("ChangeType = 'insert' OR ChangeType = 'update_postimage'")
    # df = df.withColumn("index", F.row_number().over(Window.orderBy("IndexUID")))
    # df = df.filter((df.index >= 0) & (df.index <= 100)).drop("index")

    # Convert name cols to Uppercase 
    df = df.withColumn("PartyName",F.upper(F.col("PartyName")))\
      .withColumn("LastName", F.upper(F.col("LastName"))).withColumn("FirstName", F.upper(F.col("FirstName")))\
        .withColumn("MiddleName", F.upper(F.col("MiddleName"))).withColumn("SuffixName", F.upper(F.col("SuffixName")))
    
    # add last_commit_timestamp
    if not df.isEmpty():
      config["LastCommitTimeStamp"] = df.agg(F.max("CommitTimestamp").alias("max_commit_timestamp")).collect()[0]["max_commit_timestamp"]
    else:
      config["LastCommitTimeStamp"] = config["LastRunTimeStamp"]

    # ensure there has been an update before further processing
    if config["LastCommitTimeStamp"] > config["LastRunTimeStamp"]:
      # split df into upsert data and deleted data
      df_upsert = df.drop("Rank").filter("ChangeType = 'insert' OR ChangeType = 'update_postimage'")
      # display(df_upsert.limit(50))
      df_delete = df.drop("Rank").filter("ChangeType = 'delete'")
      # display(df_delete.limit(50))
    
      # remove any record already successfully processed, if required
      try:
        if config["reconcile_archive_with_new_load"]:
          logg("Removing any record already successfully processed")
          df_index_archive = get_archive_df(index_table_path, deleted_index_table_path)           
          df_archive = df_index_archive.drop(*cols_after_transform)

          # remove any processed records from new load
          df_upsert = df_upsert.join(df_archive, on=["IndexUID", "CommitVersion"], how="left_anti")
          
      except Exception as e:
        tb = traceback.format_exc() # enable error traceback
        raise Exception(f"Error occurred while removing processed records from new load: {e} \n{tb}")

    # add any previous fails
    if not df_failed.isEmpty():
      df_upsert = df_upsert.unionByName(df_failed)

    # add n_records to metadata
    config["CDCRecordsInserted"] = df_upsert.filter("ChangeType = 'insert'").count()
    config["CDCRecordsUpdated"] = df_upsert.filter("ChangeType = 'update_postimage'").count()
    config["CDCRecordsDeleted"] = df_delete.count()
    logg(f"""Processing {config['CDCRecordsInserted']} new records, 
            {config['CDCRecordsUpdated']} updated records, and {config['CDCRecordsDeleted']} deleted records""")

  except Exception as e:
    tb = traceback.format_exc() # enable error traceback
    raise Exception(f"Unable to get data from source: {e} \n{tb}")    
  
  # Stage 3: Remove Deleted data from Index
  if not df_delete.isEmpty():    
    try:
      logg("Removing deleted data from index")
      df_delete = df_delete.select("IndexUID", "CommitVersion")
      df_delete = df_delete.persist()
      df_delete_payload = df_delete.withColumn("payload", F.to_json(F.struct("IndexUID")))
      df_delete_status = df_delete_payload.withColumn("DeleteStatus", delete_from_index_udf(F.col("payload")))
      # display(df_delete_status.filter("DeleteStatus != 'Success'"))
      # logg("Deleted data successfully removed from index")
      
    except Exception as e:
      tb = traceback.format_exc() # enable error traceback
      raise Exception(f"Error occurred while removing deleted data from index: {e} \n{tb}")

    # Add deleted records to archive
    try:
      # update cummulative table - deletes
      logg("Processing and adding deleted records to archive")
      df_delete_status.drop("payload").write.format("delta").mode("append")\
        .partitionBy("CommitVersion").save(deleted_index_table_path)

      df_delete.unpersist()
      
    except Exception as e:
        tb = traceback.format_exc() # enable error traceback
        raise Exception(f"Error occurred while adding deleted records to archive: {e} \n{tb}")
  
  else:
    logg("No deleted records found")   
    config["CDCRecordsDeleted"] = "0" 

  # Stage 4: Transform Data (Only applicable to new inserts or updated data)
  if not df_upsert.isEmpty():
    logg("Processing profiles to be added/updated")      
    try:
      # Creating the sounds-like code for the PartyName column using soundex library
      logg("Creating the sounds-like code for the Name columns")
      df_soundslike = df_upsert.withColumn("FirstNameSoundsLike", modifiedNysiis(F.col("FirstName")))\
        .withColumn("LastNameSoundsLike", modifiedNysiis(F.col("LastName")))\
          .withColumn("MiddleNameSoundsLike", modifiedNysiis(F.col("MiddleName")))
      # display(df_soundslike.limit(5))

      # Creating Full Profile as a summary of each party data
      logg("Creating full profiles as summary of each party data")
      df_summary = df_soundslike.withColumn(
          "FullProfile",
          F.concat_ws(". ", *[F.when(is_valid_value(col_name),
                                     F.concat_ws(": ", F.lit(col_name), F.col(col_name))
                                     ).otherwise(None)
                              for col_name in embedding_cols
                              ])
          ).withColumn("FullProfile", F.regexp_replace(F.col("FullProfile"), "PartyName: ", ""))
      # display(df_summary.limit(5))

      # # Count Number of Tokens
      # df_tokens = df_summary.withColumn("token_count", count_tokens_udf(F.col("FullProfile")))
      # # display(df_tokens.filter(df_tokens.token_count.isNotNull()))
      # avg_tokens = df_tokens.select(F.avg("token_count")).collect()[0][0]
      # print(f"Average token count per row: {avg_tokens:.2f}")

      # Generating embeddings of Full Profiles, with retries
      logg("Generating embeddings for each profile") 
      df_embed = df_summary.withColumn("Embeddings", generate_embeddings_udf(F.col(config["summary_col"])))
      # display(df_embed.limit(5))
    
    except Exception as e:
      tb = traceback.format_exc() # enable error traceback
      raise Exception(f"Error occurred while transforming new/updated data: {e} \n{tb}")

    # Stage 5: Load New/Updated Data
    try:
      # load embeddings and config to vector db
      logg("Loading new/updated records to index")
      df_index = df_embed.withColumn("payload", F.to_json(F.struct(*df_embed.columns)))
      df_load_status = df_index.withColumn("LoadStatus", load_to_index_udf(F.col("payload")))
      # display(df_load_status.filter("LoadStatus != 'Success'"))
      # logg("New/updated records successfully loaded to index")
    
    except Exception as e:
      tb = traceback.format_exc() # enable error traceback
      raise Exception(f"Error occurred while loading data: {e} \n{tb}")

    # Add new/updated records to archive
    try:
      # update cummulative table - upserts
      if df_failed.isEmpty():
        logg("Processing and appending new/updated records to archive")
        df_load_status.drop("payload").write.format("delta").mode("append")\
          .partitionBy("CommitVersion").save(index_table_path)
      else:
        logg("Processing and merging new/updated records to archive")
        update_load_archive(df_load_status.drop("payload"), index_table_path)

    except Exception as e:
      tb = traceback.format_exc() # enable error traceback
      raise Exception(f"Error occurred while archiving index data: {e} \n{tb}")
  
  else:
    logg("No new/updated records found")
    config["CDCRecordsInserted"] = "0"
    config["CDCRecordsUpdated"] = "0"
  
  # Stage 6: Execute any required pipeline maintenance steps
  # function to backup archived records, whenever it is required
  try:
    if config["enable_archive_backup"]:
      today = datetime.today().weekday()
      if today == config["backup_day"]:
        logg("Running Delta table backup...")
        if path_exists(index_table_path):
          (spark.read.format("delta").load(index_table_path)
            .write.format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .save(index_backup_table_path))
        if path_exists(deleted_index_table_path):
          (spark.read.format("delta").load(deleted_index_table_path)
            .write.format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .save(deleted_index_backup_table_path))

        logg("Backup completed successfully.")

  except Exception as e:
    tb = traceback.format_exc() # enable error traceback
    raise Exception(f"Error occurred during archived records backup: {e} \n{tb}")

  # function to optimize archived records, whenever it is required
  try:
    if config["enable_archive_optimization"]:
      today = datetime.today()
      if today == config["optimization_day"]:
        logg("Running monthly archive optimization...")
        if path_exists(index_table_path):          
          spark.sql(f""" OPTIMIZE delta.`{index_table_path}`
                    ZORDER BY (IndexUID, CommitVersion) """)
          
        if path_exists(deleted_index_table_path):
          spark.sql(f"""OPTIMIZE delta.`{deleted_index_table_path}`
                    ZORDER BY (IndexUID, CommitVersion)""")
          
        logg("Archive optimization completed successfully.")

  except Exception as e:
    tb = traceback.format_exc() # enable error traceback
    raise Exception(f"Error occurred during archived records optimization: {e} \n{tb}")

  # function to reconcile archived records with index records, whenever it is required
  try:
    if config["reconcile_archive_with_index"]:
      logg("Reconciling archived records with index records")        
      df_index_archive = get_archive_df(index_table_path, deleted_index_table_path)
      df_index_archive = df_index_archive.drop("LoadStatus") 

      window_spec = Window.partitionBy("IndexUID").orderBy(F.col("CommitVersion").desc())
      df_index_archive = (df_index_archive.withColumn("row_num", F.row_number().over(window_spec))\
        .filter(F.col("row_num") == 1).drop("row_num"))
      df_index = df_index_archive.withColumn("payload", F.to_json(F.struct(*df_index_archive.columns)))

      # load data
      df_load_status = df_index.withColumn("LoadStatus", load_to_index_udf(F.col("payload")))
      display(df_load_status.filter("LoadStatus != 'Success'"))
      logg("Index reconciling task completed")

  except Exception as e:
    tb = traceback.format_exc() # enable error traceback
    raise Exception(f"Error occurred while reconciling archived records with index records: {e} \n{tb}")

  # log end of batch
  config["BatchEndTime"] = dt_to_str(datetime.now())
  config["Logs"] = log_messages
  logg("Run Completed")

  # exit notebook
  dbutils.notebook.exit(json.dumps(config, indent=2))


# COMMAND ----------

# MAGIC %md
# MAGIC #### Entry Point

# COMMAND ----------

if __name__ == "__main__":
  main(pipeline_configs)
